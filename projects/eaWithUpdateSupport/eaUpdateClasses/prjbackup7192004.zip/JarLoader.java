/*
 * JarLoader.java
 *
 * Created on July 16, 2004, 12:16 AM
 */

import java.util.Hashtable;
import java.net.URL;
import java.net.MalformedURLException;
import java.net.URLConnection;
import java.util.jar.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.security.CodeSource;
import java.security.cert.Certificate;
import java.io.IOException;

/**
 *
 * @author  aaronsc
 */
public class JarLoader extends Thread 
{
    private String m_cCacheFileName = null;
    private URL m_cUrl;
    private Hashtable m_cRawData;
    private CodeSource m_cCodeSource = null;
    
    /** Creates new JarLoader */
    public JarLoader(String url, Hashtable rawData, String cacheFileName) 
    {
        super("JarLoader"); // sets the thread name
        try 
        {
            m_cUrl = new URL(url);
        } 
        catch (MalformedURLException e) 
        {
            System.out.println("Malformed url: " + e.getMessage());            
        }
        m_cRawData = rawData;
        m_cCacheFileName = cacheFileName;
    }
    
    
    public void load() 
    {
                try
                {                    
                    URLConnection jarConnection = (URLConnection)m_cUrl.openConnection();
                    jarConnection.connect();

                    int jarSize = jarConnection.getContentLength();                    
                    // You could make a progress dialog and set the maximum here: monitor.setMaximum(jarSize);                    
                    
                    JarInputStream input = new JarInputStream(jarConnection.getInputStream());                    
                    JarOutputStream output = new JarOutputStream(new FileOutputStream(new File(m_cCacheFileName)));
                    
                    JarEntry zip = input.getNextJarEntry();
                    JarEntry ent = null;
                    
                    int total = 0;
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();                    
                    byte buffer[] = new byte[2048];
                                        
                    for (;zip != null;) {
                        int len = input.read(buffer);
                        if (len < 0 ) 
                        {
                            m_cRawData.put(zip.getName(),baos.toByteArray());
                            output.putNextEntry(zip);
                            output.write(baos.toByteArray());
                            baos.reset();
                            ent = zip;
                            zip = input.getNextJarEntry();
                        } else {
                            baos.write(buffer, 0, len);
                            total += len;
                            // Update the monitor if you have implemented it: monitor.setProgress(total);
                        }
                        if (input.available()==0) break;
                    }
                    m_cCodeSource = new CodeSource(m_cUrl, ent.getCertificates());                    
                    output.close();
                } 
                catch (IOException e) 
                {
                    e.printStackTrace();
                }
           // }
    }
    
    public java.security.cert.Certificate[] getCertificates() 
    {
        return m_cCodeSource.getCertificates();
    }
    
    public CodeSource getCodeSource() 
    {
        return m_cCodeSource;
    }
}
