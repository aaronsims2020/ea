/*
 * NetClassLoader.java
 *
 * Created on July 16, 2004, 12:17 AM
 */
import java.util.jar.*;
import java.util.Hashtable;
import java.net.URL;
import java.net.URLConnection;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;
import java.util.HashMap;
import java.util.Map;
import java.security.SecureClassLoader;
import java.security.CodeSource;
import java.security.Permission;
import java.io.File;
import java.io.BufferedReader;
import java.util.StringTokenizer;
import java.util.NoSuchElementException;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;
import java.security.cert.Certificate;

/**
 *
 * @author  aaronsc
 */
public class NetClassLoader extends SecureClassLoader 
{
    private class MySecurityManager extends SecurityManager 
    {
        public void checkPermission(Permission p) 
        {
           // Dummy implementation... this is not probably a good idea...
        }
    }
    private Hashtable m_cRawData = new Hashtable();
    private CodeSource m_cCodeSource;
    private String m_cUrl;

    private HashMap lookupTable = new HashMap();
    URL m_cCodeBase;
    private static int m_nBuild = 0;

    private String m_cTempPath = "";
    
    /** Creates new NetClassLoader */
    public NetClassLoader(ClassLoader parent) {
        super(parent);
    }
    
    public NetClassLoader() {
        System.setSecurityManager(new MySecurityManager());
        // Resolve temp -filepath to store local downloaded jar files
        try {
            File f = File.createTempFile("build", "num");            
            m_cTempPath = f.getAbsolutePath().substring(0, f.getAbsolutePath().indexOf("build"));
            f.delete();
        } catch (Throwable e) {
            System.out.println("Cannot create temp files " + e);
            e.printStackTrace();
        }
    }

    /**
     * returns map with key=jar filename, value = Integer build number
     */
    public static Map getCachedJarMap() {
        return cacheIndex;
    }
    
    public void init(URL codebase, String lookupTablefile) {
        m_cCodeBase = codebase;
        try {
            URL url = new URL(m_cCodeBase.toString() + lookupTablefile);
            URLConnection tblConnection = (URLConnection)url.openConnection();
            tblConnection.connect();

            InputStream in = null;
            in = new JarInputStream(tblConnection.getInputStream());
            
            BufferedReader r = new BufferedReader(new InputStreamReader(in));
            try {
                String s = r.readLine();
                // read build number
                StringTokenizer t = new StringTokenizer(s, " ");
                if (!t.nextToken().equals("Build")) {
                    throw new NullPointerException("Cannot read build number from " + lookupTablefile);
                }
                m_nBuild = Integer.parseInt(t.nextToken());
                do {
                    t = new StringTokenizer(s, " ");
                    try {
                        String jar = t.nextToken();
                        String cl = t.nextToken();
                        lookupTable.put(cl, jar);
                    } 
                    catch (NoSuchElementException elex) {
                    }
                    s = r.readLine();
                } while(s != null);
            } catch (IOException ex) {
                System.out.println("IOException when reading from lookup table"+m_cCodeBase.toString()+lookupTablefile+" "+ ex);
                ex.printStackTrace();
            }
        } catch (Throwable e) {
            System.out.println("Exception when reading from"+m_cCodeBase.toString()+lookupTablefile+" " + e);
            e.printStackTrace();
        }
        loadCacheIndex();
    }
    
    private static HashMap cacheIndex = new HashMap();
    
    private void loadCacheIndex() {
        String buildfile = m_cTempPath + "cache.dat";
        cacheIndex.clear();
        try {
            File f = new File(buildfile);
            BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
            String s = r.readLine();
            do {
                StringTokenizer t = new StringTokenizer(s, " ");
                String filename = t.nextToken();
                int build = Integer.parseInt(t.nextToken());
                cacheIndex.put(filename, new Integer(build));
                s = r.readLine();
            } while (s != null);
            r.close();
        } catch (Throwable e) {
            System.out.println("Exception loading "+buildfile+" " + e);
        }
        
    }
    
    // Saves local cache index, a file containing
    // jarfilename buildnum
    // to resolve which files we already have downloaded
    private void saveCacheIndex() {
        String buildfile = m_cTempPath + "vbjavacache.idx";
        //System.out.println("Saving cache idx into " + buildfile);
        try {
            File f = new File(buildfile);
            f.delete();
            f.createNewFile();
            PrintWriter p = new PrintWriter(new FileOutputStream(f));
            Iterator i = cacheIndex.entrySet().iterator();
            while (i.hasNext()) {
                Map.Entry e = (Map.Entry)i.next();
                p.println(""+e.getKey() + " " + e.getValue());
            }
            p.close();
        } catch (Throwable e) {
            System.out.println("Exception saving "+buildfile+" " + e);
        }
    }
    
    // Loads a jar file via JarLoader
    public void LoadJar(String url, String cachejar) {
        JarLoader jl = new JarLoader(url, m_cRawData, m_cTempPath+cachejar);
        jl.load();
        m_cCodeSource = jl.getCodeSource();
        cacheIndex.put(cachejar, new Integer(m_nBuild));
        saveCacheIndex();
    }

    // Load jar from cache    
    public void LoadJarFromCache(String jar) {
        try {
            File f = new File(m_cTempPath + jar);
            JarInputStream input = new JarInputStream(new FileInputStream(f));
            JarEntry zip = input.getNextJarEntry();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte buffer[] = new byte[1024];
            for (;zip != null;) {
                int len = input.read(buffer);
                if (len < 0 ) {
                    m_cRawData.put(zip.getName(),baos.toByteArray());
                    baos.reset();
                    zip = input.getNextJarEntry();
                } else {
                    baos.write(buffer, 0, len);
                }
                if (input.available()==0) break;
            }
        }  catch (Throwable e) {
            System.out.println("Error loading cached jar : " + jar + " ex" + e);
            e.printStackTrace();
        }
    }
    
    // Overridden to find out where we can get the class from
    public Class findClass(String name) {
        return findJarClass(name);
    }
    
    
    public Class findJarClass(String name) {
        String cname = name.replace('.', '/') + ".class";
        byte [] data = (byte[]) m_cRawData.get(cname);
        if (data != null) {
             // the class is found in the loaded jars, define it
            m_cRawData.remove(cname);
            return defineClass(name, data, 0, data.length, m_cCodeSource);
        } else {
            String jar = (String)lookupTable.get(cname);
            if (jar != null) {
                // Jar not loaded, fetch it
                // First, check which build number we have in cache
                Integer build = (Integer)cacheIndex.get(jar);
                if (build != null) {
                    if (build.intValue() == m_nBuild) {
                        LoadJarFromCache(jar);
                        return findJarClass(name);
                    }
                }
                LoadJar(m_cCodeBase.toString()+jar, jar);
                return findJarClass(name);
            } else {
                System.out.println("ERROR:"+cname+" not found!");
                return null;
            }
        }        
    }

    // Overridden to resolve resources
    public java.net.URL getResource(String name) {
        try {
            return new java.net.URL("jar:"+m_cCodeBase.getProtocol()+"://"+m_cCodeBase.getHost()+m_cCodeBase.getPath()+lookupTable.get(name)+"!/"+name);
        } catch (Throwable e) {
            System.out.println("Malformed URL:" + "jar:"+m_cCodeBase.getProtocol()+"://"+m_cCodeBase.getHost()+m_cCodeBase.getPath()+lookupTable.get(name)+"!/"+name);
            return null;
        }
    }
    
    // do the same here, not implemented in my project... 
    // excercise for the reader ;-)
    public InputStream getResourceAsStream(String name) {
        return null;
    }
}

