/*
 * LoaderTest.java
 *
 * Created on July 16, 2004, 1:10 AM
 */
import java.net.URL;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.io.File;
import java.io.IOException;
import java.net.URLClassLoader;

/**
 *
 * @author  aaronsc
 */
public class LoaderTest
{
   // NetClassLoader m_cClassLoader;
    //Object m_cClassInstance;
    //Class  m_cClass;

    public LoaderTest() {
        //m_cClassLoader = new NetClassLoader();
         try 
        { 
            // init the classloader with the filename of the lookup -tbl -file
          //  m_cClassLoader.LoadJar("file:/c:/Documents and Settings/aaronsc/studio5se_user/examples_me/obfuscate2/testModel/ZipClassLoader/eademo.jar", "cache.jar");
          //  m_cClassLoader.init(new URL("file:/c:/Documents and Settings/aaronsc/studio5se_user/examples_me/obfuscate2/testModel/ZipClassLoader/"), "eademo.jar");
            // Load the initial class, and fire it up
            // the custom classloader will intercept this, and
            // load the respective jar that contains this code
           // m_cClass = m_cClassLoader.loadClass("com.trinity.ea.EvaluateAnywhere");
           // m_cClassInstance = m_cClass.newInstance();
                         
            //m_cClass.getMethod("init", null).invoke(m_cClassInstance, null );
    URL[] urls = null;
    try {
        // Convert the file object to a URL

        URL url = new URL("file:/c:/Documents and Settings/aaronsc/studio5se_user/examples_me/obfuscate2/testModel/JarCache/eademo.jar");
        urls = new URL[]{url};
    } catch (MalformedURLException e) {
    }
    
    try {
        // Create a new class loader with the directory
        ClassLoader cl = new URLClassLoader(urls);
    
        // Load in the class
        Class cls = cl.loadClass("com.trinity.ea.EvaluateAnywhere");
    
        // Create a new instance of the new class
       Object myObj = cls.newInstance();
    } catch (IllegalAccessException e) {
    } catch (InstantiationException e) {
    } catch (ClassNotFoundException e) {
    }            
            
        } 
        catch(Exception e) 
        {
            e.printStackTrace();
        }       
        
    }
        
    public static void main(String[] args) 
    {
        new LoaderTest();
    }
}


